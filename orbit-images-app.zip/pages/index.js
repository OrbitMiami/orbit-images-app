export default function Home() {
  return (
    <main>
      <h1>Welcome to Orbit.Images</h1>
      <p>This is your Next.js landing page.</p>
    </main>
  );
}
